var lang = ""; // can be one of ["en", "de"]
var show_status = true; 
var show_percentage = true; 
var minimal = false; // remove the border
