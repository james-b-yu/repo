var show_seconds = false; 
var show_date = true; 
var show_weather = true; 
var show_rain = true; // will be hidden anyway if chance of rain is 0%
var minimal = false; // even more minimal?
var clock_format = "auto"; // can be one of ["24h", "12h", "auto"]
var language = "en"; // can be one of ["de", "en"]